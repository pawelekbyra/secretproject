
export const DEFAULT_AVATAR_URL = 'https://4r6bgzvgnm5exo49.public.blob.vercel-storage.com/jajk.png';
