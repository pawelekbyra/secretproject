declare module 'uuid';
